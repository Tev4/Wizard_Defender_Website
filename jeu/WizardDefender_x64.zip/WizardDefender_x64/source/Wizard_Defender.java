import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Wizard_Defender extends PApplet {

//Importation de bibliothèques externes


//Variables de toutes les images
PImage personnage;
PImage background;
PImage tree1;
PImage tree2;
PImage tour1;
PImage tour2;
PImage shadow;
PImage shadow2;
PImage pFaceLeft;
PImage pFaceRight;
PImage projectile;
PImage monstre;
PImage freezeIcon;
PImage frozen;
PImage hp1;
PImage hp2;
PImage hp3;
PImage hp4;
PImage hp5;
PImage noHp;
PImage logo;
PImage filtreClair;
PImage filtreClairMort;
PImage boutonRetour;
PImage boutonRetourMort;
PImage boutonRestart;
PImage couronne;
PImage rightClick;

//Variable timer pour l'animation du monstre
float delaiAnim = 0;

//Variable de difficulté
byte difficulte; //0 = facile / 1 = moyen / 2 = difficile

//Variables d'activation des menus
boolean menu = true;
boolean mort = false;
boolean credits = false;

//Coordonnées du personnage
float px= 225;
float py= 465;
float pxSave;
float pySave;
float pxSave2;

//Coordonnées des monstres
float mobX = 250;
float mobY = 0;

//Variable qui empeche le monstre de descendre plus bas que le chateau
float mobYMax = 400;

//Vitesses de déplacement
float speed = 3; //Vitesse du joueur
int freezeSpeed = 1;
float mobSpeed = 1; //Vitesse du squelette
boolean movingR = false;
boolean movingL = false;

//Variable des dégâts subis
int damageTaken = 0;

//Variables d'activations des tirs / sorts
boolean shooting = false;
boolean freezeCD = false;

//Variables pour le sort Freeze
int freezeCDCount = 0;
int freezeTimer = 0;

//Coordonnées du tir principal
float tirX;
float tirY;

//Vitesse du tir principal
float bulletSpeed = 7;

//Variable timer pour l'augmentation de la vitesse de jeu
int speedTimer = 0;

//Variables de score
float score;
int scoreSave;

//Variables d'enregistrement du meilleur score
boolean newHighscore = false;
String[] highscore = new String[3];

//Variables de musique
Minim minim;

AudioPlayer musiqueMenu;
AudioSample buttonMouseover;
AudioSample fireball;
AudioSample lose;

//Variables d'activation des musiques
boolean musiqueMenuActivation = true;
boolean buttonMouseoverActivation = false;
boolean lost = false;

//Variables police d'écriture
PFont pixel;

public void setup() {
  //Définition de la résolution du jeu
  

  //Création de l'objet Minim
  minim = new Minim(this);

  //Chargement des musiques
  chargementMusiques();

  //Chargement des images
  chargementTextures();

  //Chargement des polices
  chargementPolices();
} // FIN SETUP

public void draw() {
  //Affichage des menus
  if (menu == true && credits == false) {
    menu();
  }
  if (credits == true) {
    credits();
  }

  //CODE JEU
  if (menu == false && (mort == false) && credits == false) {

    //Arret de la musique du menu principal si le joueur entre en jeu
    if (menu == false) {
      musiqueMenu.pause();
    }

    //Dessin du terrain de jeu
    image(background, 0, 0);
    image(monstre, mobX+3, mobY); //Squelette
    image(tree1, 50, 0); //Arbre en haut a gauche
    image(tree2, 400, 70); //Arbre a droite
    image(shadow, 30, 432); //Ombre de la tour du chateau à gauche
    image(shadow, 295, 432); //Ombre de la tour du chateau à droite
    image(personnage, px, py); //Sorcier
    image(freezeIcon, 5, 30); //Icone du sort Freeze
    image(rightClick, 15, 80); //Icone d'un clic droit en dessous du sort

    //Animation du monstre
    animationMonstre();

    //Affichage des points de vie
    affichagehp();

    //Affichage et déplacement du monstre
    monstre();

    //Déplacements du joueur
    deplacementFluide();

    //Gère le fonctionnement du sort Freeze
    freezeCooldown();
    freezeDuree();

    //Rends certains objets transparents lorsque un monstre ou le personnage passe dessous
    transparenceObjets();

    //TIR
    tirPrincipalDeplacement();

    //Affichage des tours pour que les boules de feu soient tirées en dessous
    image(tour1, 50, 425);
    image(tour2, 315, 425);

    //Affichage du score
    affichageScore();
  } // FIN DU CODE JEU

  //Affichage de l'écran de mort
  mort();
} // FIN DU DRAW

public void keyPressed() {
  //TOUCHES EN JEU
  if (menu == false  && (mort == false) && credits == false) {
    deplacementDroite(); //Le personnage se déplace à droite
    deplacementGauche(); //Le personnage se déplace à gauche
  }
}

public void keyReleased() {
  if (menu == false && (mort == false) && credits == false) { 
    deplacementPetit(); //Déplace le personnage d'une case si le joueur appuies sur le clavier rapidement
    deplacementDroiteStop(); //Arrete le déplacement quand le joueur va vers la droite
    deplacementGaucheStop(); //Arrete le déplacement quand le joueur va vers la gauche
  }
}

public void mousePressed() {
  if (menu == false  && (mort == false) && credits == false) {
    tirPrincipal(); //Le joueur tire
    freeze(); //Le joueur utilise le sort Freeze
  }
}
/**
 * Fonction pour animer le squelette
 */
public void animationMonstre() {
  if (freezeSpeed == 1) {
    //Incrémentation du timer
    delaiAnim = delaiAnim+1; //Le jeu se rafraichis 60 fois par seconde donc delaiAnim = delaiAnim+60 a chaque seconde

    if (delaiAnim == 40/9*2) {//Chargement de l'image n°1 
      monstre = loadImage("animations/sprite1.png");
    }
    if (delaiAnim == 40/9*3) {//Chargement de l'image n°2
      monstre = loadImage("animations/sprite2.png");
    }
    if (delaiAnim == 40/9*4) {//Chargement de l'image n°3
      monstre = loadImage("animations/sprite3.png");
    }
    if (delaiAnim == 40/9*5) {//Chargement de l'image n°4
      monstre = loadImage("animations/sprite4.png");
    }
    if (delaiAnim == 40/9*6) {//Chargement de l'image n°5
      monstre = loadImage("animations/sprite5.png");
    }
    if (delaiAnim == 40/9*7) {//Chargement de l'image n°6
      monstre = loadImage("animations/sprite6.png");
    }
    if (delaiAnim == 40/9*8) {//Chargement de l'image n°7
      monstre = loadImage("animations/sprite7.png");
    }
    if (delaiAnim == 40) { //L'animation est terminée au bout de 0.67 secondes
      monstre = loadImage("animations/sprite8.png");//Chargement de la derniere image
      delaiAnim = 0;//Réinitialisation du timer pour reprendre le cycle a 0
    }
  }
}
/**
 * Fonction pour lancer l'attaque principale
 */
public void tirPrincipal() {
  if ((mouseButton == LEFT) && (movingR == false) && (movingL == false) && (shooting == false)) {
    //Sauvegarde des coordonnées ou le joueur a tiré
    tirX = px;
    tirY = py;

    //Lancement du son de tir
    fireball.trigger();

    //Change l'orientation du joueur
    personnage = loadImage("textures/pFaceTop.png");

    //Enclenche le déplacement de la boule de feu
    shooting = true;
  }
}

/**
 * Fonction pour déplacer la boule de feu quand le joueur a tiré
 */
public void tirPrincipalDeplacement() {
  if (shooting == true) {

    //Affiche la boule de feu
    image(projectile, tirX+5, tirY);

    //Déplace la boule de feu vers le haut
    tirY = tirY - bulletSpeed;

    //Si la boule de feu touche le squelette, il meurt et la boule de feu est réinitialisée 
    if (tirX+12 >= mobX && tirX+12 <= mobX+25 && tirY <= mobY) {
      mobY = -50;
      tirY = 0;
    }
    //Si la balle sors de l'écran ou touche le squelette, le tir est réinitialisé pour que le joueur puisse re-tirer
    if (tirY <= 0) {
      shooting = false;
    }
  }
}

/**
 * Fonction pour lancer le sort freeze
 */
public void freeze() {
  if ((mouseButton == RIGHT) && (freezeCD == false)) {
    freezeSpeed = 0; //Empeche le monstre de descendre
    freezeTimer = 0; //Enclenche le timer qui compte la durée du sort
    freezeCDCount = 600; //Enclenche le timer qui compte le temps de recharge du sort
    freezeIcon = loadImage("textures/freezeIconOnCD.png"); //L'image du sort deviens grisée pour indiquer qu'il est en train de se recharger
    freezeCD = true; //Activation du temps de recharge
  }
}

/**
 * Fonction pour afficher la glace sur le squelette et afficher la durée restante du sort Freeze
 */
public void freezeDuree() {
  if (freezeTimer < 180 && freezeCD == true) {
    //Incrémentation du timer
    freezeTimer = freezeTimer + 1;

    //Affichage de la glace
    image(frozen, mobX+3, mobY);

    //Affichage du temps restant de l'effet sous le squelette
    fill(18, 44, 82);
    rect(mobX, mobY+52, 30, 5);
    fill(60, 140, 255);
    rect(mobX, mobY+52, (180 - freezeTimer)/6, 5);
  } else {
    //Le squelette peut de nouveau bouger
    freezeSpeed = 1;
  }
}

/**
 * Fonction qui gère le temps de recharge du sort Freeze
 */
public void freezeCooldown() { 
  if (freezeCD == true) {
    //Affichage du temps de recharge restant
    textAlign(CENTER);
    text(ceil(freezeCDCount/60), 30, 60);

    //Décrémentation de la variable temps de recharge
    if (freezeCDCount > 0) {
      freezeCDCount = freezeCDCount - 1;
    } 
    //Si le temps de recharge est terminé, l'icone du sort reprends ses couleurs et le joueur peut de nouveau l'utiliser
    else if (freezeCDCount == 0) {
      freezeIcon = loadImage("textures/freezeIcon.png");
      freezeCD = false;
    }
  }
}
/**
 * Fonction pour charger toutes les images de textures
 */
public void chargementTextures() {
  personnage = loadImage("data/textures/pFaceTop.png");
  freezeIcon = loadImage("data/textures/freezeIcon.png");
  frozen = loadImage("data/textures/frozen.png");
  background = loadImage("data/textures/background.png");
  tree1 = loadImage("data/textures/tree1.png");
  tree2 = loadImage("data/textures/tree2.png");
  tour1 = loadImage("data/textures/tour.png");
  tour2 = loadImage("data/textures/tour.png");
  shadow = loadImage("data/textures/shadow.png");
  pFaceLeft = loadImage("data/textures/pFaceLeft.png");
  pFaceRight = loadImage("data/textures/pFaceRight.png");
  projectile = loadImage("data/textures/projectile.png");
  monstre = loadImage("data/animations/static.png");
  noHp = loadImage("data/textures/noHp.png");
  boutonRetour = loadImage("data/textures/boutonRetour.png");
  boutonRetourMort = loadImage("data/textures/boutonRetourMort.png");
  boutonRestart = loadImage("data/textures/boutonRestart.png");
  filtreClair = loadImage("data/textures/filtreClair.png");
  filtreClairMort = loadImage("data/textures/filtreClairMort.png");
  logo = loadImage("data/textures/logo.png");
  couronne = loadImage("data/textures/crown.png");
  rightClick = loadImage("data/textures/rightClick.png");
}
/**
 * Fonction pour charger tout les sons / musiques du jeu
 */
public void chargementMusiques() {
  lose = minim.loadSample("data/sounds/lose.wav");
  fireball = minim.loadSample("data/sounds/fireball.wav");
  buttonMouseover = minim.loadSample("data/sounds/buttonMouseover.wav");
  musiqueMenu = minim.loadFile("data/sounds/menu.wav");
}
/**
 * Fonction pour charger toutes les polices d'écriture
 */
public void chargementPolices() {
  pixel = createFont("data/fonts/ARCADEPI.TTF", 20);
}
/**
 * Fonction pour enclencher le déplacement vers la gauche
 */
public void deplacementGauche() {
  if ((keyCode == LEFT) && (px != 0) && (movingR == false) && (movingL == false)) {
    pxSave = px; //Sauvegarde sur 2 variables de la postion du joueur
    pxSave2 = px;
    movingL = true; //Enclenche le déplacement a gauche
    personnage = pFaceLeft; //Change l'orientation du joueur
  }
}
/**
 * Fonction pour enclencher le déplacement vers la droite
 */
public void deplacementDroite() {
  if ((keyCode == RIGHT) && (px != 475) && (movingR == false) && (movingL == false)) {
    pxSave = px;
    pxSave2 = px;
    movingR = true;
    personnage = pFaceRight;
  }
}
/**
 * Fin du déplacement du joueur vers la droite (se situe dans le keyReleased)
 */
public void deplacementDroiteStop() {
  if (keyCode == RIGHT) {
    px = pxSave;
    movingR = false;
  }
}
/**
 * Fin du déplacement du joueur vers la gauche (se situe dans le keyReleased)
 */

public void deplacementGaucheStop() {
  if (keyCode == LEFT) {
    px = pxSave;
    movingL = false;
  }
}
/**
 * Permet de déplacer le personnage et de toujours l'aligner avec les cases d'apparition du squelette
 */
public void deplacementFluide() {
  //Vers la droite
  if (movingR == true && px != 475) {
    //Déplacement du joueur
    px = px + speed;

    //Alignement du joueur si il est entre deux "cases"
    if (px >= pxSave+25 && px != 475 + speed) {
      pxSave = pxSave+25;
      px = pxSave;
    }
  }
  //Vers la gauche
  if (movingL == true && px != 0) {
    //Déplacement du joueur
    px = px - speed;

    //Alignement du joueur si il est entre deux "cases"
    if (px <= pxSave-25 && px != 0 - speed) {
      px = pxSave-25;
      pxSave = pxSave-25;
    }
  }
}
/**
 * Assure le déplacement si le joueur appuie rapidement sur une touche de déplacement
 */

public void deplacementPetit() {
  //Vers la droite
  if (px < pxSave2 + 25 && keyCode == RIGHT) {
    px = pxSave2 + 25;
    pxSave = pxSave + 25;
  }
  //Vers la droite
  if (px > pxSave2 - 25 && keyCode == LEFT) {
    px = pxSave2 - 25;
    pxSave = pxSave - 25;
  }
}
/**
 * Fonction pour afficher le menu des credits
 */
public void credits() {
  //Affichage de toutes les images et textes du menu
  background(10, 14, 17);
  textSize(30);
  textAlign(CENTER);
  text("Credits", width/2, 50);
  boutonRetour.resize(50, 50);
  image(boutonRetour, width/2 - 25, 450);
  text("Graphismes", width/2, 190);
  textSize(18);
  text("Sprites du squelette : wulax", width/2, 220);
  text("Fond d'ecran du gameplay : Little Malice", width/2, 250);
  textSize(25);
  text("Musiques", width/2, 300);
  textSize(18);
  text("Menu : The Bard's Tale by RandomMind", width/2, 330);

  //Bouton retour
  //Si le joueur passe sa souris au dessus du bouton
  if (mouseX >= width/2-25 && mouseX <= width/2+25 && mouseY >= 450 && mouseY <= 500 && credits == true) { 
    //"Surlignage" du bouton
    filtreClair.resize(50, 50);
    image(filtreClair, width/2 - 25, 450);

    //Un son s'active
    if (buttonMouseoverActivation == true) {
      buttonMouseover.trigger();
      buttonMouseoverActivation = false;
    }
    //Si le joueur fais un clique gauche, le menu credits disparait et il reviens sur le menu principal
    if (mousePressed && mouseButton == LEFT) {
      credits = false;
    }
  } else {
    //Reinitialisation de la variable qui active le son du bouton quand le joueur n'est plus dessus
    buttonMouseoverActivation = true;
  }
}
/**
 * Fonction pour afficher le menu principal
 */
public void menu() {
  PImage backgroundMenu;
  PImage bouton;

  backgroundMenu = loadImage("textures/menu.png");
  bouton = loadImage("textures/bouton.PNG");

  //Affichage de toutes les images et textes du menu
  image(backgroundMenu, 0, 0);
  image(bouton, 75, 350); //Bouton mode facile
  image(bouton, 200, 350); //Bouton mode normal
  image(bouton, 325, 350); //Bouton mode difficile
  image(logo, 50, 65);

  //Redimensionnement du bouton pour le bouton credits
  bouton.resize(80, 30);
  image(bouton, 400, 20); //Bouton credits

  //Mise en boucle de la musique du menu principal
  if (musiqueMenuActivation == true) {
    musiqueMenu.rewind();
    musiqueMenu.loop();
    musiqueMenuActivation = false;
  }

  textFont(pixel);
  textAlign(CENTER);
  fill(93, 222, 168);
  textSize(15);
  text("Credits", 440, 40);
  textSize(18);
  text("Facile", 125, 395);
  text("Normal", 250, 395);
  text("Difficile", 375, 395);
  image(couronne, 95, 410);
  image(couronne, 220, 410);
  image(couronne, 345, 410);

  //Lecture des meilleurs scores
  highscore = loadStrings("data/highscore.txt");
  text(highscore[0], 135, 425); //Affichage du meilleur score du mode facile
  text(highscore[1], 260, 425); //Affichage du meilleur score du mode normal
  text(highscore[2], 385, 425); //Affichage du meilleur score du mode difficile

  // Bouton mode facile
  //Si le joueur passe sa souris au dessus du bouton
  if (mouseX >= 75 && mouseX <= 175 && mouseY >= 350 && mouseY <= 450 && credits == false) {
    //"Surlignage" du bouton
    image(filtreClair, 75, 350);

    //Un son s'active
    if (buttonMouseoverActivation == true) {
      buttonMouseover.trigger();
      buttonMouseoverActivation = false;
    }
    //Si le joueur fais un clique gauche, le menu principal disparait le jeu se lance en mode facile
    if (mousePressed && mouseButton == LEFT) {
      difficulte = 0;
      menu = false;
    }
    //Bouton mode normal
    //Si le joueur passe sa souris au dessus du bouton
  } else if (mouseX >= 200 && mouseX <= 300 && mouseY >= 350 && mouseY <= 450 && credits == false) {
    //"Surlignage" du bouton
    image(filtreClair, 200, 350);

    //Un son s'active
    if (buttonMouseoverActivation == true) {
      buttonMouseover.trigger();
      buttonMouseoverActivation = false;
    }
    //Si le joueur fais un clique gauche, le menu principal disparait le jeu se lance en mode normal
    if (mousePressed && mouseButton == LEFT) {
      difficulte = 1;
      menu = false;
    }
    // Bouton mode difficile
    //Si le joueur passe sa souris au dessus du bouton
  } else if (mouseX >= 325 && mouseX <= 425 && mouseY >= 350 && mouseY <= 450 && credits == false) {
    //"Surlignage" du bouton
    image(filtreClair, 325, 350);

    //Un son s'active
    if (buttonMouseoverActivation == true) {
      buttonMouseover.trigger();
      buttonMouseoverActivation = false;
    }
    //Si le joueur fais un clique gauche, le menu principal disparait le jeu se lance en mode difficile
    if (mousePressed && mouseButton == LEFT) {
      difficulte = 2;
      menu = false;
    }
    //Bouton credits
    //Si le joueur passe sa souris au dessus du bouton
  } else if (mouseX >= 400 && mouseX <= 480 && mouseY >= 20 && mouseY <= 50 && credits == false) {
    //"Surlignage" du bouton
    filtreClair.resize(80, 30);
    image(filtreClair, 400, 20);

    //Un son s'active
    if (buttonMouseoverActivation == true) {
      buttonMouseover.trigger();
      buttonMouseoverActivation = false;
    }
    //Si le joueur fais un clique gauche, le menu principal disparait le menu des crédits s'affiche
    if (mousePressed && mouseButton == LEFT) {
      credits = true;
    }
  } else {
    //Reinitialisation de la variable qui active le son du bouton quand le joueur n'est plus dessus et redimensionnage du filtre "Surlignage"
    filtreClair.resize(100, 100);
    buttonMouseoverActivation = true;
  }
}
/**
 * Fonction pour savoir quand le joueur est mort et afficher le menu lié a sa mort
 */
public void mort() {
  if (mort == false) {
    if (difficulte == 0 && damageTaken >= 5) {
      mort = true;
      lost = true;
      if (lost == true) {
        lose.trigger();
        lost = false;
      }
    }
    if (difficulte == 1 && damageTaken >= 3) {
      mort = true;
      lost = true;
      if (lost == true) {
        lose.trigger();
        lost = false;
      }
    }
    if (difficulte == 2 && damageTaken >= 1) {
      mort = true;
      lost = true;
      if (lost == true) {
        lose.trigger();
        lost = false;
      }
    }
  } else if (mort == true) {

    //REINITIALISATION DES VARIABLES
    freezeCDCount = 600;
    damageTaken = 0;
    speed = 3;
    mobSpeed = 1;
    px= 225;
    py= 465;
    mobX = 250;
    mobY = 0;
    score = 0;

    //Affichage de toutes les images du menu
    PImage backgroundMort;
    backgroundMort = loadImage("textures/mort.png");
    image(backgroundMort, 0, 0);
    boutonRetourMort.resize(50, 50);
    image(boutonRetourMort, width/2 - 62, 450);
    boutonRestart.resize(50, 50);
    image(boutonRestart, width/2 + 12, 450);

    //Affichage de tout les textes du menu
    textAlign(CENTER);
    textFont(pixel);
    textSize(50);
    text("GAME OVER", width/2, 200);
    textSize(20);
    text("Score : " + scoreSave, width/2, height/2);

    //Sauvegarde du nouveau meilleur score
    if (scoreSave > Integer.parseInt(highscore[0]) && difficulte == 0) { //Si c'est en mode Facile
      newHighscore = true;
      highscore[0] = Integer.toString(scoreSave);
      saveStrings("data/highscore.txt", highscore);
    } else if (scoreSave > Integer.parseInt(highscore[1]) && difficulte == 1) { //Si c'est en mode Normal
      newHighscore = true;
      highscore[1] = Integer.toString(scoreSave);
      saveStrings("data/highscore.txt", highscore);
    } else if (scoreSave > Integer.parseInt(highscore[2]) && difficulte == 2) { //Si c'est en mode Difficile
      newHighscore = true;
      highscore[2] = Integer.toString(scoreSave);
      saveStrings("data/highscore.txt", highscore);
    } else if (newHighscore == true) {
      text("NOUVEAU MEILLEUR SCORE !", width/2, height/2+20);
    }

    // Bouton restart
    //Si le joueur passe sa souris au dessus du bouton
    if (mouseX >= width/2+12 && mouseX <= width/2+62 && mouseY >= 450 && mouseY <= 500 && mort == true) {
      //"Surlignage" du bouton
      filtreClairMort.resize(50, 50);
      image(filtreClairMort, width/2 + 12, 450);

      //Un son s'active
      if (buttonMouseoverActivation == true) {
        buttonMouseover.trigger();
        buttonMouseoverActivation = false;
      }
      //Si le joueur fais un clique gauche, le menu mort disparait et le jeu se relance
      if (mousePressed && mouseButton == LEFT) {
        newHighscore = false;
        mort = false;
      }
    }
    // Bouton retour
    //Si le joueur passe sa souris au dessus du bouton
    else if (mouseX >= width/2-62 && mouseX <= width/2-12 && mouseY >= 450 && mouseY <= 500 && mort == true) {
      //"Surlignage" du bouton
      filtreClairMort.resize(50, 50);
      image(filtreClairMort, width/2 - 62, 450);

      //Un son s'active
      if (buttonMouseoverActivation == true) {
        buttonMouseover.trigger();
        buttonMouseoverActivation = false;
      }
      //Si le joueur fais un clique gauche, le menu mort disparait et il reviens sur le menu principal
      if (mousePressed && mouseButton == LEFT) {
        musiqueMenuActivation = true;
        newHighscore = false;
        mort = false;
        menu = true;
      }
    } else {
      //Reinitialisation de la variable qui active le son du bouton quand le joueur n'est plus dessus et redimensionnage du filtre "Surlignage"
      filtreClair.resize(100, 100);
      buttonMouseoverActivation = true;
    }
  }
}
/**
 * Fonction pour gérer le déplacement et l'apparition du squelette
 */
public void monstre() {
  //la vitesse du monstre augmente de plus en plus selon la difficulté
  //Mode Facile
  if (speedTimer == 60 && difficulte == 0) { //Chaque seconde la vitesse du monstre augmente de 0.075
    mobSpeed = mobSpeed + 0.075f;
    speed = speed + 0.075f;

    //Réinitialisation du timer
    speedTimer = 0;
  }
  //Mode Normal
  if (speedTimer == 60 && difficulte == 1) { //Chaque seconde la vitesse du monstre augmente de 0.1
    mobSpeed = mobSpeed + 0.1f;
    speed = speed + 0.1f;

    //Réinitialisation du timer
    speedTimer = 0;
  }
  //Mode Difficile
  if (speedTimer == 60 && difficulte == 2) { //Chaque seconde la vitesse du monstre augmente de 0.125
    mobSpeed = mobSpeed + 0.125f;
    speed = speed + 0.125f;

    //Réinitialisation du timer
    speedTimer = 0;
  } else {
    //Incrémentation du timer qui permet d'augmenter la vitesse du jeu
    speedTimer = speedTimer + 1;
  }

  //Déplacement automatique des monstres vers le bas
  if (mobY < mobYMax && mobY != -50) {

    mobY = mobY + mobSpeed * freezeSpeed;
  }
  //Calculs des dégats subis
  if (mobY >= mobYMax && mort == false && menu == false) {
    damageTaken = damageTaken + 1;
  }
  //Réinitialise le squelette quand il s'est fait toucher ou quand il touche le chateau
  if (mobY >= mobYMax || mobY == -50) {
    mobY = 0;
    //Enlève l'effet de gel du squelette car il est mort
    freezeTimer = 180;
  }
  //Coordonnée X du spawn du squelette aléatoire
  if (mobY == 0) {
    mobX = PApplet.parseInt(random(0, 20))*25;
  }
}
/**
 * Fonction pour afficher le nombre de points de vie selon la difficulté et les dégats subis
 */
public void affichagehp() {
  //Affichage des hp
  if (difficulte == 0 && damageTaken == 0) { //MODE FACILE
    hp5 = loadImage("textures/hp.png"); //Rafraichissement de tout les hp en début de partie
    hp4 = loadImage("textures/hp.png");
    hp3 = loadImage("textures/hp.png");
    hp2 = loadImage("textures/hp.png");
    hp1 = loadImage("textures/hp.png");
  }
  if (difficulte == 0 && damageTaken >= 1) {// Le joueur a 4 points de vie restants
    hp5 = noHp;//Le point de vie perdu devient gris
  }
  if (difficulte == 0 && damageTaken >= 2) {// Le joueur a 3 points de vie restants
    hp4 = noHp;//Le point de vie perdu devient gris
  }
  if (difficulte == 0 && damageTaken >= 3) {// Le joueur a 2 points de vie restants
    hp3 = noHp;//Le point de vie perdu devient gris
  }
  if (difficulte == 0 && damageTaken >= 4) {// Le joueur a 1 point de vie restant
    hp2 = noHp;//Le point de vie perdu devient gris
  }
  if (difficulte == 1 && damageTaken == 0) { // MODE MOYEN
    hp1 = loadImage("textures/hp.png"); //Rafraichissement de tout les hp en début de partie
    hp2 = loadImage("textures/hp.png");
    hp3 = loadImage("textures/hp.png");
    hp4 = loadImage("textures/void.png");
    hp5 = loadImage("textures/void.png");
  }
  if (difficulte == 1 && damageTaken >= 1) { // Le joueur a 2 points de vie restants
    hp3 = noHp;//Le point de vie perdu devient gris
  }
  if (difficulte == 1 && damageTaken >= 2) {// Le joueur a 1 point de vie restant
    hp2 = noHp;//Le point de vie perdu devient gris
  }
  if (difficulte == 2 && damageTaken >= 0) {//MODE DIFFICILE
    hp1 = loadImage("textures/hp.png"); //Rafraichissement de tout les points de vie en début de partie
    hp2 = loadImage("textures/void.png");
    hp3 = loadImage("textures/void.png");
    hp4 = loadImage("textures/void.png");
    hp5 = loadImage("textures/void.png");
  }
  //Affichage de tout les coeurs (Points de vie)
  image(hp1, 0, 0);
  image(hp2, 25, 0);
  image(hp3, 50, 0);
  image(hp4, 75, 0);
  image(hp5, 100, 0);
}
/*
 Fonction pour retourner le score du joueur
 */
public float score() {
  float score = 0;
  if (difficulte == 0) { //Le joueur gagne 50% du score normal en mode facile
    score = (50*speed-50*3);
  }
  if (difficulte == 1) { //Le joueur gagne le score normal en mode normal
    score = (100*speed-100*3);
  }
  if (difficulte == 2) { //Le joueur gagne 150% du score normal en mode difficile
    score = (150*speed-150*3);
  }
  return score;
}

/**
 * Fonction pour afficher le score en jeu
 */
public void affichageScore() {
  fill(255);
  textSize(25);
  textFont(pixel);
  textAlign(RIGHT);
  if (mort == false) { //Le score ne doit pas s'afficher a cet endroit quand le joueur est mort (voir onglet Mort)
    text("SCORE :", 420, 20);
    score = score(); //Le score prends la valeur retournée par la fonction score
    scoreSave = ceil(score); //Arrondis le score pour le transformer en int
    text(scoreSave, width, 20); //Affichage du score
  }
}
/**
 * Fonction pour rendre certains objets transparents quand certaines entités passent en dessous
 */
public void transparenceObjets() {
  //Les arbres deviennent transparents si il y a le squelette dans les feuilles
  //Arbre n°1
  if (mobX >= 50 && mobX <= 150 && mobY >= 0 && mobY <= 80) {
    tree1 = loadImage("textures/tree1Transparent.png");
  } else {
    //Le squelette n'est plus dessous donc la transparence s'enlève
    tree1 = loadImage("textures/tree1.png");
  }
  //Arbre n°2
  if (mobX >= 400 && mobX <= 500 && mobY >= 60 && mobY <= 160) {
    tree2 = loadImage("textures/tree2Transparent.png");
  } else {
    //Le squelette n'est plus dessous donc la transparence s'enlève
    tree2 = loadImage("textures/tree2.png");
  }


  //Les tours deviennent transparentes si le personnage passe en dessous
  //Tour n°1
  if (px >= 50 && px <= 186) {
    tour1 = loadImage("textures/tourTransparente.png");
  } else {
    //Le personnage n'est plus dessous donc la transparence s'enlève
    tour1 = loadImage("textures/tour.png");
  }
  //Tour n°2
  if (px >= 315 && px <= 451) {
    tour2 = loadImage("textures/tourTransparente.png");
  } else {
    //Le personnage n'est plus dessous donc la transparence s'enlève
    tour2 = loadImage("textures/tour.png");
  }
}
  public void settings() {  size (500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Wizard_Defender" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
